# Ye1 临床分析 — Apple 芯片 Mac

## 安装到你的 Agent

> 请先识别我的系统并阅读 `toolkit/START-HERE.md`；如果适用，就把 Ye1 临床分析 Skill 安装到当前研究项目，准备依赖并完成自检，告诉我结果和开始方式。

本包联网获取固定官方 Python wheel 和缺失的基础程序。
