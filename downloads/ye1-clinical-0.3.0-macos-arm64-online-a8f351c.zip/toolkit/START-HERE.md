# 安装到你的 Agent

适用于 Apple 芯片 macOS 14 或更新版本。将工具箱解压到独立目录，在 Codex 中打开研究项目并告诉 Agent：

> 请先识别我的系统并阅读这个工具箱的安装说明；如果适用，就把 Ye1 临床分析 Skill 安装到当前研究项目，准备依赖并完成自检，告诉我结果和开始方式。

联网时运行 `bash setup-online.sh <已有研究目录>`；完整离线包从 `toolkit` 目录运行 `bash setup-offline.sh <已有研究目录>`。按需在命令末尾添加 `--method <方法ID>` 或 `--all`。首次预检和恢复等细节见主 Skill 的 `INSTALL.md`。
