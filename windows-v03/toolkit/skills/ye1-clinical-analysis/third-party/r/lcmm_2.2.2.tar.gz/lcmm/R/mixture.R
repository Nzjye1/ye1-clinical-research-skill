mixture <- function(x){x}
